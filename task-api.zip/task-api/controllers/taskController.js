const db = require('../models/db');

// Helper function for date validation
const isFutureOrToday = (dateStr) => {
  const inputDate = new Date(dateStr);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return inputDate >= today;
};

exports.createTask = (req, res) => {
  const { title, status, dueDate } = req.body;

  if (!title || !status || !dueDate) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  if (!['pending', 'done'].includes(status)) {
    return res.status(400).json({ message: 'Invalid status' });
  }

  if (!isFutureOrToday(dueDate)) {
    return res.status(400).json({ message: 'Due date must be today or in the future' });
  }

  const query = 'INSERT INTO tasks (title, status, dueDate) VALUES (?, ?, ?)';
  db.query(query, [title, status, dueDate], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.status(201).json({
        id: result.insertId,
        title,
        status,
        dueDate
      });
  });
};

exports.getTasks = (req, res) => {
  const { status } = req.query;
  let query = 'SELECT * FROM tasks';
  const params = [];

  if (status) {
    if (!['pending', 'done'].includes(status)) {
      return res.status(400).json({ message: 'Invalid status filter' });
    }
    query += ' WHERE status = ?';
    params.push(status);
  }

  db.query(query, params, (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.status(200).json(results);
  });
};
